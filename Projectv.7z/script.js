const breastCancerSurvivors = [
    {
        name: "Sheryl Crow",
        story: "The famous singer-songwriter Sheryl Crow was diagnosed with breast cancer in 2006. After undergoing a challenging journey of treatment, including a complex surgery, intensive radiation therapy, and holistic healing practices, she not only overcame the disease but also became an unwavering advocate for breast cancer awareness. Sheryl's battle with breast cancer transformed her into a beacon of hope for countless others facing similar struggles. She channeled her resilience into empowering women to prioritize their health, share their experiences, and seek early detection, ultimately saving lives."
    },
    {
        name: "Robin Roberts",
        story: "Robin Roberts, the beloved co-host of Good Morning America, faced a life-altering moment in 2007 when she was diagnosed with breast cancer. Her courageous journey through this turbulent period became an inspirational narrative, raising profound awareness about the disease. She meticulously documented her battles and triumphs, giving a voice to millions. With a radiant smile and a determination that knew no bounds, Robin emerged as a shining symbol of hope and strength. Her story not only inspired those grappling with breast cancer but also touched the hearts of everyone who witnessed her incredible resilience."
    },
    {
        name: "Kylie Minogue",
        story: "In 2005, the world was shaken by the news that the Australian pop icon Kylie Minogue had been diagnosed with breast cancer. Despite the emotional turmoil, Kylie embarked on a journey of recovery filled with determination and courage. Successful treatment paved the way for her triumphant return to the stage, where she not only continued her illustrious music career but also used her global platform to advocate passionately for breast cancer awareness and early detection. Through her story, Kylie became a beacon of hope, spreading the crucial message that early intervention and awareness can make all the difference in the fight against breast cancer."
    },
    {
        name: "Christina Applegate",
        story: "In 2008, the actress and comedian Christina Applegate received the life-altering diagnosis of breast cancer. Faced with this daunting challenge, Christina made a courageous decision, opting for a double mastectomy. Her journey toward recovery was marked by resilience and a dedication to raising awareness for breast cancer research and early detection. Christina's story exemplifies the strength and power of those who have battled this disease and emerged as fierce advocates. Her unwavering commitment to helping others confront breast cancer's challenges has had a profound impact, offering a guiding light to many in their darkest hours."
    },
    {
        name: "Joan Lunden",
        story: "In 2014, Joan Lunden, the former host of Good Morning America, confronted the harsh reality of a diagnosis of triple-negative breast cancer. Her path to recovery was fraught with obstacles, including the rigors of chemotherapy. Despite the hardships, Joan transformed her experience into a powerful platform for breast cancer awareness. She openly shared her journey, providing invaluable insights into the trials and tribulations of breast cancer treatment. Joan's story became a source of inspiration, encouraging others to confront their fears and offering guidance on navigating the challenges of breast cancer with resilience and grace."
    }
];

const swiperWrapper = document.getElementById("swiper-wrapper");
const addStoryButton = document.getElementById("add-story-button");
const userStoryTextarea = document.getElementById("user-story");
const nextStoryButton = document.createElement("button");
nextStoryButton.textContent = "Next Story";
nextStoryButton.style.display = "none";
let currentStoryIndex = 0;

// Initialize the swiper
const swiper = new Swiper('.swiper-container', {
    loop: false, // Turn off loop for stories
    pagination: {
        el: '.swiper-pagination',
    },
});

// Function to create a story slide
function createStorySlide(survivor, isLast) {
    const slide = document.createElement("div");
    slide.classList.add("swiper-slide");

    const content = document.createElement("div");
    content.classList.add("story-content");

    const name = document.createElement("h3");
    name.textContent = `Patient: ${survivor.name}`;

    const story = document.createElement("p");
    story.textContent = `Story: ${survivor.story}`;

    content.appendChild(name);
    content.appendChild(story);
    slide.appendChild(content);
    swiperWrapper.appendChild(slide);

    if (!isLast) {
        const nextButtonContainer = document.createElement("div");
        nextButtonContainer.classList.add("next-button-container");
        nextButtonContainer.appendChild(nextStoryButton.cloneNode(true));
        slide.appendChild(nextButtonContainer);
    }
}

// Add the breast cancer survivors' stories
breastCancerSurvivors.forEach((survivor, index) => createStorySlide(survivor, index === breastCancerSurvivors.length - 1));

// Add event listener for the "Add Story" button
addStoryButton.addEventListener("click", () => {
    const userStory = userStoryTextarea.value;
    if (userStory) {
        const userSlide = createStorySlide({ name: "You", story: userStory }, false);
        swiper.appendSlide(userSlide);
        swiper.update();
        userStoryTextarea.value = "";
    }
});

// Add event listener for the "Next Story" button
nextStoryButton.addEventListener("click", () => {
    currentStoryIndex = (currentStoryIndex + 1) % breastCancerSurvivors.length;
    swiper.slideTo(currentStoryIndex);
});

// Show the "Next Story" button
swiper.on('slideChange', () => {
    if (currentStoryIndex === breastCancerSurvivors.length - 1) {
        nextStoryButton.style.display = "none";
    } else {
        nextStoryButton.style.display = "block";
    }
});
